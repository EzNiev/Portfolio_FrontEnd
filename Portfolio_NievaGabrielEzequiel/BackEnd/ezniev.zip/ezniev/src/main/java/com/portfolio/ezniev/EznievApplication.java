package com.portfolio.ezniev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EznievApplication {

	public static void main(String[] args) {
		SpringApplication.run(EznievApplication.class, args);
	}

}
