package com.portfolio.ezniev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EznievApplicationTests {

	@Test
	void contextLoads() {
	}

}
